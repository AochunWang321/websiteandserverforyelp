var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var indexRouter = require('./routes/index');

var app = express();
app.all("*", function (req, res, next) {
  //设置允许跨域的域名，*代表允许任意域名跨域
  res.header("Access-Control-Allow-Origin", "*");
  //允许的header类型(包含token)
  res.header("Access-Control-Allow-Headers", "content-type,token,id,X-Requested-With");
  //跨域允许的请求方式
  res.header("Access-Control-Allow-Methods", "DELETE,PUT,POST,GET,OPTIONS");
  res.header("X-Powered-By", '3.2.1')
  res.header("Content-Type", "application/json;charset=utf-8");
  if (req.method.toLowerCase() == 'options')
    res.send(200);  //让options尝试请求快速结束
  else
    next();
});

/* 
  fetch(`https://api.yelp.com/v3/autocomplete`, {
    headers: {
      'Authorization': 'Bearer 1DbQ9QCFUS-Jb7eY8n0kVJhmaVY83ZN0EsIt5jDijIIDzQYpkta5iEqiCNjFw_MXRCA8MCE8c3MLllKMMRMmgD9TenApf6gREtcSY861QqfHMmUEG6CQHWGZypc3Y3Yx'
    }
  })
    .then(res => res.json())
    .then(json => res.send(json));
*/
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);

module.exports = app;
