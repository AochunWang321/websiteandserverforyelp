var express = require('express');
var router = express.Router();
var fetch = require('node-fetch');
var router = express.Router();
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

// /* autocomplete */
router.get('/autocomplete', function (req, res, next) {
  console.log(req.query)
  fetch(`https://api.yelp.com/v3/autocomplete?text='${req.query.text}'`, {
    headers: {
      'Authorization': 'Bearer 1DbQ9QCFUS-Jb7eY8n0kVJhmaVY83ZN0EsIt5jDijIIDzQYpkta5iEqiCNjFw_MXRCA8MCE8c3MLllKMMRMmgD9TenApf6gREtcSY861QqfHMmUEG6CQHWGZypc3Y3Yx'
    }
  })
    .then(res => res.json())
    .then(json => {
      res.send({ ret: 000, message: json })
    })
    .catch((err) => {
      res.json({ ret: 400, message: err });
    })
});
/* searchin */
router.get('/searchin', function (req, res, next) {
  console.log(req.query)
  var keyword = req.query.keyword;
  var distance = req.query.distance;
  var category = req.query.category;
  var lat = req.query.lat;
  var lng = req.query.lng;
  let url = 'https://api.yelp.com/v3/businesses/search?term=' + keyword + '&latitude=' + lat + '&longitude=' + lng + '&categories=' + category + '&radius=' + distance + '&limit25'
  fetch(url, {
    headers: {
      'Authorization': 'Bearer 1DbQ9QCFUS-Jb7eY8n0kVJhmaVY83ZN0EsIt5jDijIIDzQYpkta5iEqiCNjFw_MXRCA8MCE8c3MLllKMMRMmgD9TenApf6gREtcSY861QqfHMmUEG6CQHWGZypc3Y3Yx'
    }
  })
    .then(res => res.json())
    .then(json => {
      res.send({ ret: 000, message: json })
    })
    .catch((err) => {
      res.json({ ret: 400, message: err });
    })
});
/* https://api.yelp.com/v3/businesses/search */
router.get('/busi', function (req, res, next) {
  console.log(req.query)
  var id = req.query.id;
  let url = 'https://api.yelp.com/v3/businesses/' + id
  fetch(url, {
    headers: {
      'Authorization': 'Bearer 1DbQ9QCFUS-Jb7eY8n0kVJhmaVY83ZN0EsIt5jDijIIDzQYpkta5iEqiCNjFw_MXRCA8MCE8c3MLllKMMRMmgD9TenApf6gREtcSY861QqfHMmUEG6CQHWGZypc3Y3Yx'
    }
  })
    .then(res => res.json())
    .then(json => {
      res.send({ ret: 000, message: json })
    })
    .catch((err) => {
      res.json({ ret: 400, message: err });
    })
});
router.get('/reviews', function (req, res, next) {
  console.log(req.query)
  var id = req.query.id;
  let url = `https://api.yelp.com/v3/businesses/${id}/reviews`
  fetch(url, {
    headers: {
      'Authorization': 'Bearer 1DbQ9QCFUS-Jb7eY8n0kVJhmaVY83ZN0EsIt5jDijIIDzQYpkta5iEqiCNjFw_MXRCA8MCE8c3MLllKMMRMmgD9TenApf6gREtcSY861QqfHMmUEG6CQHWGZypc3Y3Yx'
    }
  })
    .then(res => res.json())
    .then(json => {
      res.send({ ret: 000, message: json })
    })
    .catch((err) => {
      res.json({ ret: 400, message: err });
    })
});
module.exports = router;
